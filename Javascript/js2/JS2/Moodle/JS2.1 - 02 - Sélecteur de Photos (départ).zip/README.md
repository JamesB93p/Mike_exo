## Enoncé

En **HTML** créer un bouton et un rectangle de 400x300 aux coins arrondis et de couleur bleue dans le contenu principal.

Quand on clique sur le bouton, cela cache ou affiche le rectangle en-dessous.

Quand la souris rentre dans le rectangle, celui-ci bascule en rouge.

Quand on double-clique sur le rectangle, celui-ci bascule en vert.

## Détails

* Comme pour l'exercice Dragon Slayer, organiser le code en trois parties : les variables, les fonctions et enfin le code principal.
* Codes couleurs **CSS** : bleu = royalblue, rouge = firebrick, vert = limegreen.
* Le changement de couleur du couleur doit s'animer.