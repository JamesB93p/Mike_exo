<?php
/*
Exercice :

Créer une BDD boutique qui contient une table produits.
Champs de la table : id_produit, reference, categorie, titre, description, couleur, taille, prix, stock.

Créer un formulaire permettant d'insérer des produits dans la base de données

Inserez du contenu dans la base

Executez une requete INSERT, UPDATE, DELETE 

Afficher sous forme de tableau HTML l'ensemble de la table (nom des champs/colones + contenu)

Si le champs "reference" est laissé vide lors de l'ajout d'un produit, afficher un message d'erreur sinon enregistrez le produit

Si le champs "titre" fait moins de 3 caractères ou plus de 20 caractères, indiquer à l'internaute d'insérer un titre de taille correcte sinon enregistré le produit

afficher un message lorsqu'un produit a bien été enregistré
*/









