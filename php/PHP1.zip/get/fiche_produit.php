<?php
echo 'ID produit : ' . $_GET['idProduit'];

echo '<pre>'; print_r($_GET); echo '</pre>';