<h1>Liste des produits dans ma boutique</h1>

<a href="fiche_produit.php?idProduit=1">Produit 1</a>
<a href="fiche_produit.php?idProduit=2">Produit 2</a>
<a href="fiche_produit.php?idProduit=3">Produit 3</a>
<a href="fiche_produit.php?idProduit=4">Produit 4</a>