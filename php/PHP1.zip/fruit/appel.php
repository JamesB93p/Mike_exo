<?php
// Exercice : afficher le prix de 2kg de bananes en executant la fonction sans copier/coller ni la changer
include("fonction.inc.php");
echo calcul("bananes", 2000);