			<nav>
				<a href="accueil.php">Accueil</a>
				<a href="actualites.php">Actulités</a>
				<a href="contact.php">Contact</a>
				<a href="quisommesnous.php">Qui sommes nous ?</a>
			<nav>