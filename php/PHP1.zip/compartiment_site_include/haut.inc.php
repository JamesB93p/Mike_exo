<!DOCTYPE html>
<html>
<head>
	<title>Ma page</title>
	<link rel="stylesheet" href="style.css">
</head>
	<body>
		<div id="conteneur">
			<header>
				<img src="webforce3.png" width="100" height="60">
				<h1>La force est puissante en vous!!</h1>
			</header>