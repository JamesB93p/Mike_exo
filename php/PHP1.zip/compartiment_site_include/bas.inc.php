			<footer>
				(c) GL - Plan du site
			</footer>
		</div>
	</body>
</html>