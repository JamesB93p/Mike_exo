<?php
include_once("haut.inc.php");
include_once("menu.inc.php");
?>
			<section>
				Voici le contenu de la page d'actualités<br>
				Voici le contenu de la page d'actualités<br>
				Voici le contenu de la page d'actualités<br>
				Voici le contenu de la page d'actualités<br>
				Voici le contenu de la page d'actualités<br>
				Voici le contenu de la page d'actualités<br>
			</section>
<?php
include_once("bas.inc.php");
?>