<?php
include_once("haut.inc.php");
include_once("menu.inc.php");
?>
			<section>
				Voici le contenu de la page de contact<br>
				Voici le contenu de la page de contact<br>
				Voici le contenu de la page de contact<br>
				Voici le contenu de la page de contact<br>
				Voici le contenu de la page de contact<br>
				Voici le contenu de la page de contact<br>
			</section>
<?php
include_once("bas.inc.php");
?>