<?php
 ?>

 <!DOCTYPE html>
 <html>
     <head>
         <meta charset="utf-8">
         <title>Exercice 2</title>
     </head>
     <body>

     </body>
 </html>
