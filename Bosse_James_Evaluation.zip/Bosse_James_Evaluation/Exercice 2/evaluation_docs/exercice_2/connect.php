<?php

$db = new PDO('mysql:host=localhost;dbname=userslist;charset=utf8', 'root', '');